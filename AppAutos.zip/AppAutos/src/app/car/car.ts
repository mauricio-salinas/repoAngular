export class Car{
  constructor(
      public brand :string,
      public model:string,
      public miles:number,
      public color:string
  ){}
}
