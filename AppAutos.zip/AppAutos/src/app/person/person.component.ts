import { Component, OnInit } from '@angular/core';
import { Person } from './person';


@Component({
  selector: 'app-person',
  templateUrl: './person.component.html',
  styleUrls: ['./person.component.css']
})
export class PersonComponent implements OnInit {
  public person: Person;
  public persons: Array<Person>;

  constructor() {
    this.person = new Person ("","","");
    this.persons = [
      new Person("Mauricio","10.708.524-6","msalinas@optimisa.cl"),
      new Person("tester","1-9","tester@optimisa.cl")
    ]
  }

  ngOnInit() {
  }

  onSubmit(){
    this.persons.push(this.person)
    this.person = new Person("","","")
  }
}
