export class Person{
  constructor(
      public name :string,
      public rut:string,
      public email:string
  ){}
}
