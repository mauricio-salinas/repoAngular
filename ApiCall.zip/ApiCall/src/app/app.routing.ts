import {ModuleWithProviders} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {CompAComponent} from './comp-a/comp-a.component';
import {CompBComponent} from './comp-b/comp-b.component';

const appRoutes: Routes = [
  {path: 'compa',component: CompAComponent},
  {path: 'compb',component: CompBComponent}
];

export const appRoutingProviders: any[] = [];
export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);
