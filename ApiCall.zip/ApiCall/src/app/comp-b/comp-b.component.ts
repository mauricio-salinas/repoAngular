import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http'

@Component({
  selector: 'app-comp-b',
  templateUrl: './comp-b.component.html',
  styleUrls: ['./comp-b.component.css']
})
export class CompBComponent implements OnInit {
  title = 'Ejemplo de consumo de un servicio';
  constructor(private httpService: HttpClient) { }
  arrDogs : string [];

  ngOnInit() {
    this.httpService.get('https://dog.ceo/api/breeds/list/all').subscribe(
      data => {
        this.arrDogs = data as string []; //lleno el arreglo con datos
        console.log(this.arrDogs[1]);
      },
      (err: HttpErrorResponse) => {
        console.log ("Error:" + err.message);
      }
    );
  }

}
