import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http'

@Component({
  selector: 'app-comp-a',
  templateUrl: './comp-a.component.html',
  styleUrls: ['./comp-a.component.css']
})
export class CompAComponent implements OnInit {
  title = 'Ejemplo de lectura de un archivo JSON';
  constructor(private httpService: HttpClient) { }
  arrBirds : string [];

  ngOnInit() {
    this.httpService.get('./assets/birds.json').subscribe(
      data => {
        this.arrBirds = data as string []; //lleno el arreglo con datos
        console.log(this.arrBirds[1]);
      },
      (err: HttpErrorResponse) => {
        console.log ("Error:" + err.message);
      }
    );
  }

}
